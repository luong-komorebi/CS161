// Vo Tran Thanh Luong
// 1551020
// ex06
#include < iostream >
using namespace std;
int main()
{
	int a,b;
	cout << " Please input a:  ";
	cin >>a;
	cout << " Please input b: ";
	cin >>b;
	for ( int i =1 ; a<b-1 ; )
	{
		a+=i;
		cout << a << " " ;
	}
	return 0;
}
	